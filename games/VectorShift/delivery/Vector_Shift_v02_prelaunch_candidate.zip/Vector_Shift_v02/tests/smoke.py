from playwright.sync_api import sync_playwright
from pathlib import Path
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from functools import partial
from threading import Thread
r=Path(__file__).resolve().parents[1]
server=ThreadingHTTPServer(('127.0.0.1',0),partial(SimpleHTTPRequestHandler,directory=str(r)))
Thread(target=server.serve_forever,daemon=True).start()
HTML=(r/'index.html').read_text().replace("qa=new URLSearchParams(location.search).has('qa')", "qa=true")
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox','--disable-web-security'])
 try:
  page=browser.new_page(viewport={'width':1390,'height':930},device_scale_factor=1)
  errors=[];page.on('pageerror',lambda err:errors.append(str(err)))
  page.set_content(HTML,wait_until='load')
  page.locator('[data-testid="piece-0"]').wait_for()
  assert page.locator('.grid-cell').count()==16
  assert page.locator('.piece').count()==2
  page.screenshot(path=str(r/'artifacts/desktop.png'),full_page=True)
  page.evaluate('window.VectorShiftDebug.solveAndPlay()')
  page.locator('#modal').get_by_text('漂亮的破局。').wait_for()
  assert 1 in page.evaluate('window.VectorShiftDebug.getProgress().completed')
  page.locator('#continueWin').click()
  assert page.locator('#levelNumber').inner_text()=='02'
  page.locator('#hintButton').click()
  assert '提示' in page.locator('#feedback').inner_text()
  page.locator('#phaseButton').click()
  assert page.evaluate('window.VectorShiftDebug.getState().phase')==1
  page.locator('#undoButton').click()
  assert page.evaluate('window.VectorShiftDebug.getState().phase')==0
  page.locator('#levelMenuButton').click()
  page.locator('#modal').get_by_text('20 关逻辑之旅').wait_for()
  page.locator('#modalClose').click()
  page.evaluate('window.VectorShiftDebug.setLevel(20)')
  assert page.locator('#levelNumber').inner_text()=='20'
  page.evaluate('window.VectorShiftDebug.solveAndPlay()')
  page.locator('#modal').get_by_text('全部关卡已完成。').wait_for()
  assert 20 in page.evaluate('window.VectorShiftDebug.getProgress().completed')
  assert page.evaluate('window.VectorShiftDebug.getState().remaining.length')==0
  assert not errors,errors
  print('DESKTOP PASS — levels 1 and 20, hint, undo, phase toggle, modal')
  mob=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1,has_touch=True,is_mobile=True)
  errors2=[];mob.on('pageerror',lambda err:errors2.append(str(err)))
  mob.set_content(HTML,wait_until='load')
  mob.evaluate('window.VectorShiftDebug.setLevel(17)')
  mob.locator('.piece').first.wait_for()
  mob.screenshot(path=str(r/'artifacts/mobile.png'),full_page=True)
  bbox=mob.locator('.board').bounding_box();assert bbox['x']>=0 and bbox['x']+bbox['width']<=390,bbox
  target=mob.locator('.piece').first.bounding_box();assert target['width']>=44,target
  mob.locator('#phaseButton').tap()
  assert mob.evaluate('window.VectorShiftDebug.getState().phase')==1
  assert not errors2,errors2
  print('MOBILE PASS — touch and board in viewport, touch target',round(target['width'],1))
  # Release variants must not expose QA hooks or local playtest export.
  rc=(r/'dist/coolmath/index.html').read_text()
  release=browser.new_page(viewport={'width':375,'height':812})
  release.set_content(rc,wait_until='load')
  assert release.evaluate('typeof window.VectorShiftDebug')=='undefined'
  assert not release.locator('#exportButton').is_visible()
  assert release.locator('.piece').count()==2
  assert not release.evaluate('document.documentElement.scrollWidth > window.innerWidth')
  print('COOLMATH PRE-BUILD PASS — QA hooks hidden, telemetry export hidden, 375px layout')
 finally:browser.close();server.shutdown()
