#!/usr/bin/env python3
"""Generate solvable phase-arrow puzzles with an exact BFS proof.
No commercial game code or levels are used.
"""
from __future__ import annotations
from collections import deque
import json, random, pathlib, hashlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
D = [(0,-1),(1,0),(0,1),(-1,0)]

def rays(arrows,size):
    rays=[[0,0] for _ in arrows]
    for i,a in enumerate(arrows):
        for phase in (0,1):
            d=(a['d']+(phase if a['color']=='blue' else 0))%4
            x,y=a['x']+D[d][0],a['y']+D[d][1]
            while 0<=x<size and 0<=y<size:
                for j,b in enumerate(arrows):
                    if j!=i and x==b['x'] and y==b['y']:rays[i][phase]|=1<<j
                x+=D[d][0];y+=D[d][1]
    return rays

def solve(arrows,size,phase_enabled=True):
    n=len(arrows); masks=rays(arrows,size); initial=((1<<n)-1,0)
    q=deque([initial]); back={initial:None}; actions={}
    while q:
        mask,phase=q.popleft()
        if mask==0:
            state=(mask,phase);out=[]
            while back[state] is not None:
                out.append(actions[state]);state=back[state]
            return list(reversed(out)),len(back)
        for i in range(n):
            if mask>>i&1 and not(masks[i][phase]&mask):
                dest=(mask^(1<<i),phase)
                if dest not in back:
                    back[dest]=(mask,phase);actions[dest]=i;q.append(dest)
        dest=(mask,1-phase)
        if phase_enabled and dest not in back:
            back[dest]=(mask,phase);actions[dest]='toggle';q.append(dest)
    return None,len(back)

def stats(arrows,size):
    path,states=solve(arrows,size)
    if path is None:return None
    no,_=solve(arrows,size,False)
    num_toggle=sum(a=='toggle' for a in path)
    phase_necessary=no is None
    masks=rays(arrows,size);mask=(1<<len(arrows))-1
    initial_open=sum(not(masks[i][0]&mask) for i in range(len(arrows)))
    return {'solution':path,'minSteps':len(path),'minToggles':num_toggle,'phaseRequired':phase_necessary,'initialChoices':initial_open,'exploredStates':states}

def manual(id, size, points, teaching):
    arrows=[{'id':i,'x':x,'y':y,'d':d,'color':color} for i,(x,y,d,color) in enumerate(points)]
    info=stats(arrows,size);assert info is not None,(id,'unsolvable')
    return {'id':f'phase-{id:02}','size':size,'arrows':arrows, 'seed':-id,'teaching':teaching,'source':'editorial', 'metrics':{k:v for k,v in info.items() if k!='solution'}, 'solution':info['solution']}

# Curated opening stages teach dependency and phase without unexplained new elements.
levels=[
 manual(1,4,[(0,2,1,'gold'),(2,2,1,'gold')], '先点击前方没有箭头的金色箭头。'),
 manual(2,4,[(0,0,1,'gold'),(2,0,2,'gold'),(2,2,2,'gold')], '前方有阻挡时，先清走它。'),
 manual(3,4,[(0,1,1,'blue'),(2,1,3,'gold')], '两枚箭头互相挡住了！试试切换相位。'),
 manual(4,4,[(0,1,1,'blue'),(2,1,3,'gold'),(1,3,1,'blue'),(3,3,1,'gold')], '观察蓝色箭头会怎样改变指向。'),
]

rng=random.Random(20261021)
seen=set()
for lev in levels:
    seen.add(tuple(sorted((a['x'],a['y'],a['d'],a['color']) for a in lev['arrows'])))

# Distribute puzzle densities rather than blindly maximize count.
for number in range(5,21):
    n = min(5+(number-5)//2, 13)
    size = 5 if number<=10 else (6 if number<=17 else 7)
    required_toggle=1 if number<=13 else (2 if number>=17 else 1)
    attempts=0;chosen=None
    while attempts<300000:
        attempts+=1
        cells=rng.sample([(x,y) for y in range(size) for x in range(size)],n)
        a=[{'id':i,'x':x,'y':y,'d':rng.randrange(4),'color':('blue' if rng.random()<(.55 if number<=13 else .70) else 'gold')} for i,(x,y) in enumerate(cells)]
        sig=tuple(sorted((x['x'],x['y'],x['d'],x['color']) for x in a))
        if sig in seen:continue
        s=stats(a,size)
        if not s or not s['phaseRequired'] or s['minToggles']<required_toggle:continue
        if s['initialChoices']<1:continue
        if number>=11 and s['initialChoices']>=n-1:continue
        # In later levels, avoid trivially unconstrained boards.
        if number>=15 and s['exploredStates']<n*2:continue
        chosen=(a,s,attempts,sig);break
    if not chosen:
        raise RuntimeError(f'failed generating level {number}, attempts={attempts}')
    a,s,tries,sig=chosen;seen.add(sig)
    levels.append({'id':f'phase-{number:02}', 'size':size,'arrows':a,'seed':20261021, 'generationAttempt':tries, 'generatorVersion':1, 'teaching':'', 'source':'generated+solver_verified', 'metrics':{k:v for k,v in s.items() if k!='solution'},'solution':s['solution']})
    print(number,'n',n,'size',size,'toggles',s['minToggles'],'states',s['exploredStates'],'attempts',tries,flush=True)

# Validate replay independently, using ray masks and a mask state.
for lev in levels:
    n=len(lev['arrows']);mask=(1<<n)-1;phase=0;r=rays(lev['arrows'],lev['size'])
    for act in lev['solution']:
        if act=='toggle':phase=1-phase;continue
        assert mask>>act&1 and not(r[act][phase]&mask),lev['id']
        mask^=1<<act
    assert mask==0,lev['id']
    assert solve(lev['arrows'],lev['size'])[0]==lev['solution'],lev['id']
assert len(levels)==20
(ROOT/'data/levels.json').write_text(json.dumps(levels,ensure_ascii=False,indent=2),encoding='utf-8')
print('Saved',len(levels),'levels',[(v['metrics']['minToggles'],v['metrics']['exploredStates']) for v in levels])
