#!/usr/bin/env python3
"""Offline release gate for the single-file builds.

This intentionally re-implements the small puzzle search in Python so the
release gate still runs when the developer machine has no Node or Playwright.
It checks the shipped data and the generated channel files independently of
the browser runtime.
"""
from collections import deque
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LEVELS = json.loads((ROOT / "data/levels.json").read_text(encoding="utf-8"))
MANIFEST = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
DIRS = ((0, -1), (1, 0), (0, 1), (-1, 0))


def direction(arrow, phase):
    return (arrow["d"] + (phase if arrow["color"] == "blue" else 0)) % 4


def blockers(level, remaining, arrow_id, phase):
    arrows = {a["id"]: a for a in level["arrows"]}
    arrow = arrows[arrow_id]
    dx, dy = DIRS[direction(arrow, phase)]
    x, y = arrow["x"] + dx, arrow["y"] + dy
    hits = []
    occupied = {(a["x"], a["y"]): a["id"] for a in level["arrows"] if a["id"] in remaining}
    while 0 <= x < level["size"] and 0 <= y < level["size"]:
        if (x, y) in occupied:
            hits.append(occupied[(x, y)])
        x, y = x + dx, y + dy
    return hits


def solve(level):
    start = (frozenset(a["id"] for a in level["arrows"]), 0)
    queue = deque([start])
    previous = {start: None}
    action = {}
    while queue:
        remaining, phase = queue.popleft()
        if not remaining:
            out = []
            node = (remaining, phase)
            while previous[node] is not None:
                out.append(action[node])
                node = previous[node]
            return list(reversed(out)), len(previous)
        for arrow_id in sorted(remaining):
            if blockers(level, remaining, arrow_id, phase):
                continue
            nxt = (remaining - {arrow_id}, phase)
            if nxt not in previous:
                previous[nxt] = (remaining, phase)
                action[nxt] = {"type": "remove", "id": arrow_id}
                queue.append(nxt)
        nxt = (remaining, 1 - phase)
        if nxt not in previous:
            previous[nxt] = (remaining, phase)
            action[nxt] = {"type": "toggle"}
            queue.append(nxt)
    return None, len(previous)


def check_levels():
    assert len(LEVELS) == MANIFEST["level_count"] == 20
    seen = set()
    for index, level in enumerate(LEVELS, 1):
        assert level["id"] == f"phase-{index:02d}"
        assert 4 <= level["size"] <= 7
        coords = set()
        ids = set()
        for arrow in level["arrows"]:
            pos = (arrow["x"], arrow["y"])
            assert pos not in coords and arrow["id"] not in ids
            assert 0 <= arrow["x"] < level["size"] and 0 <= arrow["y"] < level["size"]
            assert arrow["d"] in range(4) and arrow["color"] in {"blue", "gold"}
            coords.add(pos)
            ids.add(arrow["id"])
        signature = tuple(sorted((a["x"], a["y"], a["d"], a["color"]) for a in level["arrows"]))
        assert signature not in seen
        seen.add(signature)
        actions, explored = solve(level)
        assert actions is not None
        assert len(actions) == level["metrics"]["minSteps"]
        stored = [{"type": "toggle"} if x == "toggle" else {"type": "remove", "id": x} for x in level["solution"]]
        assert actions == stored
        assert explored == level["metrics"]["exploredStates"]


def check_builds():
    for name in ("demo", "coolmath", "crazygames-basic"):
        html = (ROOT / "dist" / name / "index.html").read_text(encoding="utf-8")
        assert "INJECT_" not in html
        assert "window.VectorShiftCore" in html and "const LEVELS=" in html
        assert "https://" not in html and "http://" not in html
        if name == "demo":
            assert "window.VS_CHANNEL=\"demo\"" in html
        else:
            assert f'window.VS_CHANNEL="{name}"' in html
            assert "qa=false" in html
        if name == "coolmath":
            assert "$('exportButton').style.display='none'" in html


def main():
    check_levels()
    check_builds()
    print(f"RELEASE PASS — {len(LEVELS)} levels, independent BFS, 3 channel builds")


if __name__ == "__main__":
    main()
