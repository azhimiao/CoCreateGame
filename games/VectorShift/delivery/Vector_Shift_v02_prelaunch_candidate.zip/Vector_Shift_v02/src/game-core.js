/* Vector Shift original mechanical logic. Shared by the browser and Node test harness. */
(function(root){
'use strict';
const DX=[0,1,0,-1],DY=[-1,0,1,0];
function direction(a,phase){return (a.d+(a.color==='blue'?phase:0))%4}
function newState(level){return {phase:0,remaining:level.arrows.map(a=>a.id),moves:0,toggles:0,history:[]}}
function arrow(level,id){return level.arrows.find(a=>a.id===id)}
function blockers(level,state,id){
  const a=arrow(level,id);
  if(!a||!state.remaining.includes(id))return null;
  const d=direction(a,state.phase);let x=a.x+DX[d],y=a.y+DY[d];
  const found=[];
  while(x>=0&&x<level.size&&y>=0&&y<level.size){
    const hit=level.arrows.find(q=>q.x===x&&q.y===y&&state.remaining.includes(q.id));
    if(hit)found.push(hit.id);
    x+=DX[d];y+=DY[d];
  }
  return found;
}
function clearPath(level,state,id){let b=blockers(level,state,id);return b!==null&&b.length===0}
function transition(level,state,act){
  if(act.type==='reset')return newState(level);
  const s={phase:state.phase,remaining:[...state.remaining],moves:state.moves,toggles:state.toggles,history:state.history.map(h=>({...h,remaining:[...h.remaining]}))};
  if(act.type==='undo'){
    const last=s.history.pop();if(!last)return s;
    Object.assign(s,{phase:last.phase,remaining:[...last.remaining],moves:last.moves,toggles:last.toggles});return s;
  }
  if(act.type==='toggle'||(act.type==='remove'&&clearPath(level,s,act.id))){
    s.history.push({phase:s.phase,remaining:[...s.remaining],moves:s.moves,toggles:s.toggles});
    s.moves++;
    if(act.type==='toggle'){s.phase=1-s.phase;s.toggles++}
    else s.remaining=s.remaining.filter(x=>x!==act.id);
  }
  return s;
}
function solve(level,state,allowToggle=true){
  const ids=level.arrows.map(a=>a.id),lookup=new Map(ids.map((id,i)=>[id,i]));
  if(ids.length>23)throw new Error('Solver supports <=23 arrows');
  const ray=level.arrows.map(a=>[0,0]);
  for(let i=0;i<ids.length;i++)for(let p=0;p<2;p++){
    const a=level.arrows[i],d=direction(a,p);let x=a.x+DX[d],y=a.y+DY[d];
    while(x>=0&&x<level.size&&y>=0&&y<level.size){
      level.arrows.forEach((b,j)=>{if(b.x===x&&b.y===y)ray[i][p]|=(1<<j)});
      x+=DX[d];y+=DY[d];
    }
  }
  let mask=0;for(const id of state.remaining){const i=lookup.get(id);if(i===undefined)throw new Error('bad remaining id');mask|=1<<i}
  const init=mask*2+state.phase,queue=[init],visited=new Set([init]),back=new Map();let head=0;
  const reconstruct=node=>{let out=[];while(node!==init){let e=back.get(node);out.push(e.action);node=e.prev}return out.reverse()};
  while(head<queue.length){
    const node=queue[head++],currentMask=Math.floor(node/2),phase=node%2;
    if(currentMask===0)return {actions:reconstruct(node),explored:visited.size};
    for(let i=0;i<ids.length;i++){
      if((currentMask&(1<<i))&&!(currentMask&ray[i][phase])){
        const dest=((currentMask^(1<<i))*2+phase);
        if(!visited.has(dest)){visited.add(dest);back.set(dest,{prev:node,action:{type:'remove',id:ids[i]}});queue.push(dest)}
      }
    }
    if(allowToggle){const dest=currentMask*2+(1-phase);if(!visited.has(dest)){visited.add(dest);back.set(dest,{prev:node,action:{type:'toggle'}});queue.push(dest)}}
  }
  return {actions:null,explored:visited.size};
}
function validateLevel(level){
  if(!level||!Number.isInteger(level.size)||level.size<3||level.size>10||!Array.isArray(level.arrows))throw new Error('invalid level');
  const seen=new Set(),ids=new Set();
  for(const a of level.arrows){const c=a.x+','+a.y;
    if(seen.has(c)||ids.has(a.id)||a.x<0||a.y<0||a.x>=level.size||a.y>=level.size||![0,1,2,3].includes(a.d)||!['blue','gold'].includes(a.color))throw new Error('bad arrow '+JSON.stringify(a));
    seen.add(c);ids.add(a.id)
  }
  return true;
}
const API={direction,newState,arrow,blockers,clearPath,transition,solve,validateLevel};
root.VectorShiftCore=API;
if(typeof module!=='undefined'&&module.exports)module.exports=API;
})(typeof window!=='undefined'?window:globalThis);
