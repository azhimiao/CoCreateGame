/* Offline-first UI. All gameplay and tests use VectorShiftCore, no remote requests. */
(function(){'use strict';
const core=window.VectorShiftCore, levels=window.LEVELS||LEVELS, CHANNEL=window.VS_CHANNEL||'demo';
const $=id=>document.getElementById(id);
const STORE='vector-shift-v02-progress', TELEMETRY_STORE='vector-shift-v02-playtest';
let progress={unlocked:1,completed:[],best:{}},telemetry=[],current=0,state=null,sound=false,qa=new URLSearchParams(location.search).has('qa'),highlighted=[],blockedTimer=0,completionScheduled=false,lastDialogFocus=null;
function readLocal(key,fallback){try{const value=JSON.parse(localStorage.getItem(key)||'null');return value===null?fallback:value}catch{return fallback}}
function normalizeProgress(raw){
 const source=raw&&typeof raw==='object'?raw:{};
 const completed=[...new Set((Array.isArray(source.completed)?source.completed:[]).map(Number).filter(n=>Number.isInteger(n)&&n>=1&&n<=levels.length))];
 const storedUnlocked=Number(source.unlocked);
 const unlocked=Number.isFinite(storedUnlocked)?Math.max(1,Math.min(levels.length,Math.floor(storedUnlocked))):1;
 const best={};
 if(source.best&&typeof source.best==='object'&&!Array.isArray(source.best))for(const [key,value] of Object.entries(source.best)){
  const moves=Number(value?.moves),toggles=Number(value?.toggles);
  if(Number.isInteger(moves)&&moves>=0&&Number.isInteger(toggles)&&toggles>=0&&toggles<=moves)best[String(key)]={moves,toggles};
 }
 return {unlocked:Math.max(unlocked,Math.min(levels.length,completed.length?Math.max(...completed)+1:1)),completed,best};
}
progress=normalizeProgress(readLocal(STORE,{}));
telemetry=readLocal(TELEMETRY_STORE,[]);if(!Array.isArray(telemetry))telemetry=[];telemetry=telemetry.slice(-1000);
function persist(){try{localStorage.setItem(STORE,JSON.stringify(progress))}catch{}}
function log(event,detail={}){if(CHANNEL==='coolmath')return;const item={event,at:new Date().toISOString(),level:current+1,phase:state?.phase??0,...detail};telemetry.push(item);if(telemetry.length>1000)telemetry.shift();try{localStorage.setItem(TELEMETRY_STORE,JSON.stringify(telemetry))}catch{}}
function level(){return levels[current]}
const directionWord=['上','右','下','左'];
function arrowSvg(dir){return `<svg viewBox="0 0 32 32" aria-hidden="true" style="transform:rotate(${dir*90}deg)"><path fill="currentColor" d="M16 2.5 4 16.5h7v12.8h10V16.5h7L16 2.5z"/><path fill="#fff" opacity=".22" d="M14.2 7.2 9.1 13h2.2l4-4.5z"/><circle cx="16" cy="15" r="2.15" fill="#10292d" opacity=".75"/><circle cx="15.25" cy="14.25" r=".72" fill="#fff" opacity=".9"/></svg>`}
function message(text,tone=''){let el=$('feedback');el.textContent=text;el.className='response'+(tone?' '+tone:'')}
function display(){
 const lv=level(),board=$('board'),size=lv.size;
 board.style.gridTemplateColumns=`repeat(${size},minmax(0,1fr))`;board.innerHTML='';
 const alive=new Map(lv.arrows.filter(a=>state.remaining.includes(a.id)).map(a=>[a.x+','+a.y,a]));
 for(let y=0;y<size;y++)for(let x=0;x<size;x++){
   let cell=document.createElement('div');cell.className='grid-cell';cell.dataset.x=String(x);cell.dataset.y=String(y);
   const a=alive.get(x+','+y);
   if(a){let b=document.createElement('button');b.type='button';b.className='piece'+(a.color==='gold'?' gold':'');b.dataset.pieceId=String(a.id);b.setAttribute('aria-label',`${a.color==='blue'?'相位箭头':'固定箭头'}，第${y+1}行第${x+1}列，向${directionWord[core.direction(a,state.phase)]}`);b.setAttribute('data-testid','piece-'+a.id);
     b.innerHTML=`<span class="piece-inner">${arrowSvg(core.direction(a,state.phase))}</span>`;
     b.addEventListener('click',()=>remove(a.id));cell.appendChild(b)
   }
   board.appendChild(cell)
 }
 $('levelNumber').textContent=String(current+1).padStart(2,'0');$('phaseBadge').textContent=`PHASE ${state.phase}`;
 $('phaseButtonDetail').textContent=`切换到 PHASE ${1-state.phase}`;
 $('remainingStat').textContent=String(state.remaining.length);$('movesStat').textContent=String(state.moves);$('togglesStat').textContent=String(state.toggles);
 $('undoButton').disabled=!state.history.length;$('prevButton').disabled=current===0;
 $('nextButton').disabled=current>=levels.length-1||(!qa&&!progress.completed.includes(current+1)&&current+1>=progress.unlocked);
 const best=progress.best[String(current+1)];$('bestStat').textContent=best?`最佳 ${best.moves} 步 / ${best.toggles} 次切换`:`目标：清空所有箭头`;
 $('missionText').textContent=lv.teaching||(current>=16?'有些关卡需要多次调整相位。考虑顺序，不只是方向。':'观察挡住去路的箭头。移除前方障碍，寻找新的出口。');
}
function beep(freq=620,duration=.1){if(!sound)return;try{const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)return;const ctx=beep.ctx||(beep.ctx=new Audio()),now=ctx.currentTime,osc=ctx.createOscillator(),gain=ctx.createGain();osc.type='sine';osc.frequency.setValueAtTime(freq,now);gain.gain.setValueAtTime(.07,now);gain.gain.exponentialRampToValueAtTime(.001,now+duration);osc.connect(gain);gain.connect(ctx.destination);osc.start(now);osc.stop(now+duration+.01)}catch{}}
function ghostFor(a){if(matchMedia('(prefers-reduced-motion: reduce)').matches)return;const b=document.querySelector(`[data-piece-id="${a.id}"]`);if(!b)return;const r=b.getBoundingClientRect();const d=core.direction(a,state.phase);let ghost=document.createElement('div');ghost.className='fly-ghost';ghost.style.left=r.left+'px';ghost.style.top=r.top+'px';ghost.style.width=r.width+'px';ghost.style.height=r.height+'px';ghost.style.color=a.color==='blue'?'#78dfd3':'#f2c884';ghost.style.setProperty('--fly-x',(d===1?innerWidth:d===3?-innerWidth:0)+'px');ghost.style.setProperty('--fly-y',(d===2?innerHeight:d===0?-innerHeight:0)+'px');ghost.innerHTML=arrowSvg(d);document.body.appendChild(ghost);ghost.addEventListener('animationend',()=>ghost.remove(),{once:true});setTimeout(()=>ghost.remove(),450)}
function remove(id){if(completionScheduled||!state.remaining.includes(id))return;const b=core.blockers(level(),state,id);if(b===null)return;
 if(b.length){log('blocked_click',{id,blockedBy:b});message('前方有阻挡！先移走挡路的箭头，或者尝试切换相位。','warn');beep(170,.14);const btn=document.querySelector(`[data-piece-id="${id}"]`);btn?.classList.add('blocked');for(const hit of b){const el=document.querySelector(`[data-piece-id="${hit}"]`)?.parentNode;el?.classList.add('hit-cell')}blockedTimer++;let seq=blockedTimer;setTimeout(()=>{if(seq===blockedTimer)document.querySelectorAll('.hit-cell,.blocked').forEach(el=>el.classList.remove('hit-cell','blocked'))},620);return}
 const a=core.arrow(level(),id);ghostFor(a);state=core.transition(level(),state,{type:'remove',id});log('arrow_removed',{id,remaining:state.remaining.length});beep(590,.085);message('正确。现在重新观察棋盘。','good');display();if(state.remaining.length===0)complete();}
function toggle(){if(completionScheduled)return;state=core.transition(level(),state,{type:'toggle'});log('phase_toggle',{phase:state.phase});message(`相位已切换到 ${state.phase}。蓝色箭头改变方向。`,'good');beep(state.phase?420:500,.09);display()}
function undo(){if(completionScheduled||!state.history.length)return;state=core.transition(level(),state,{type:'undo'});log('undo');message('已撤销上一步操作。');display()}
function reset(){if(completionScheduled)return;state=core.newState(level());log('level_restart');message('关卡已重新开始。');display()}
function hint(){if(completionScheduled)return;let result=core.solve(level(),state);log('hint_requested',{solvable:!!result.actions});if(!result.actions){message('当前已经进入死局，请尝试撤销或重开。','warn');return}if(result.actions.length===0){message('已经完成关卡。','good');return}let a=result.actions[0];if(a.type==='toggle'){$('phaseButton').focus();message('提示：先切换一次相位。','good')}else{const arrow=core.arrow(level(),a.id),cell=document.querySelector(`[data-x="${arrow.x}"][data-y="${arrow.y}"]`);cell?.classList.add('hint-cell');cell?.querySelector('button')?.focus();message(`提示：尝试点击第 ${arrow.y+1} 行、第 ${arrow.x+1} 列的箭头。`,'good');setTimeout(()=>cell?.classList.remove('hint-cell'),1500)}}
function openDialog(html){lastDialogFocus=document.activeElement;$('modal').innerHTML=html;$('overlay').classList.remove('hidden');$('overlay').setAttribute('aria-hidden','false');$('modal').querySelector('button:not([disabled])')?.focus()}
function closeDialog(){const focus=lastDialogFocus;$('overlay').classList.add('hidden');$('overlay').setAttribute('aria-hidden','true');$('modal').innerHTML='';lastDialogFocus=null;if(focus&&typeof focus.focus==='function'&&document.contains(focus))focus.focus()}
function complete(){completionScheduled=true;log('level_complete',{moves:state.moves,toggles:state.toggles,optimal:level().metrics.minSteps});const key=String(current+1),old=progress.best[key];if(!old||state.moves<old.moves||state.moves===old.moves&&state.toggles<old.toggles)progress.best[key]={moves:state.moves,toggles:state.toggles};if(!progress.completed.includes(current+1))progress.completed.push(current+1);progress.unlocked=Math.min(levels.length,Math.max(progress.unlocked,current+2));persist();beep(850,.19);const last=current===levels.length-1;const delta=state.moves-level().metrics.minSteps;
 setTimeout(()=>{openDialog(`<button class="close-button" id="modalClose" type="button" aria-label="关闭">×</button><div class="modal-sub">${last?'20 / 20 — ALL COMPLETE':`STAGE ${String(current+1).padStart(2,'0')} COMPLETE`}</div><h2 id="modalTitle">${last?'全部关卡已完成。':'漂亮的破局。'}</h2><p>你用了 <strong style="color:#d6f7ed">${state.moves}</strong> 步，其中切换相位 <strong style="color:#d6f7ed">${state.toggles}</strong> 次。${delta===0?'这也是当前规则下的最短步数。':`距离求解器计算的最短路径还差 ${delta} 步，试试再次挑战。`}</p><div class="modal-actions"><button id="replayWin" type="button">再来一次</button>${last?'<button class="main-button" id="viewLevelsWin" type="button">查看全部关卡</button>':'<button class="main-button" id="continueWin" type="button">下一关 →</button>'}</div>`);$('modalClose').onclick=()=>{completionScheduled=false;closeDialog()};$('replayWin').onclick=()=>{completionScheduled=false;closeDialog();reset()};if(last)$('viewLevelsWin').onclick=()=>{completionScheduled=false;closeDialog();openLevels()};else $('continueWin').onclick=()=>{completionScheduled=false;closeDialog();select(current+1)}},matchMedia('(prefers-reduced-motion: reduce)').matches?0:230);
}
function select(index){if(index<0||index>=levels.length||(!qa&&index+1>progress.unlocked))return;completionScheduled=false;current=index;state=core.newState(level());log('level_start');message(index<=3?'从简单的规则开始，慢慢寻找出路。':'找到离开棋盘的正确顺序。');closeDialog();display();window.scrollTo({top:0,behavior:'auto'})}
function openLevels(){let tiles=levels.map((l,i)=>{const unlocked=qa||i+1<=progress.unlocked,done=progress.completed.includes(i+1);return `<button type="button" ${unlocked?'':'disabled'} data-go="${i}" class="${i===current?'current ':''}${done?'done ':''}${unlocked?'':'locked'}"><span>${String(i+1).padStart(2,'0')}</span><small>${done?'完成':unlocked?'解锁':'锁定'}</small></button>`}).join('');openDialog(`<button class="close-button" id="modalClose" aria-label="关闭">×</button><div class="modal-sub">CHOOSE YOUR STAGE</div><h2 id="modalTitle">20 关逻辑之旅</h2><p>完成当前关卡后解锁下一关。进度自动保存在本机，不上传任何数据。</p><div class="level-tiles">${tiles}</div>`);$('modalClose').onclick=closeDialog;$('modal').querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>select(Number(b.dataset.go)))}
function help(){openDialog(`<button class="close-button" id="modalClose" aria-label="关闭">×</button><div class="modal-sub">HOW TO PLAY</div><h2 id="modalTitle">三条规则，就能开始。</h2><p><strong>① 点击箭头</strong>：只要朝着箭头方向到边界之间没有其他箭头，就会离场。</p><p><strong>② 切换相位</strong>：青色箭头旋转 90°，金色箭头方向保持不变。</p><p><strong>③ 清空棋盘</strong>：选择顺序非常重要，你可以撤销、重来，或使用提示。</p><p>电脑快捷键：Space 切相位，Z 撤销，R 重开。支持触摸屏与键盘操作。</p><div class="modal-actions"><button class="main-button" id="closeHelp">开始解谜</button></div>`);$('modalClose').onclick=closeDialog;$('closeHelp').onclick=closeDialog}
function downloadTelemetry(){log('telemetry_exported');const data={build:'0.2.0',optIn:false,localOnly:true,createdAt:new Date().toISOString(),events:telemetry};let blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),href=URL.createObjectURL(blob),a=document.createElement('a');a.href=href;a.download='vector-shift-playtest.json';a.click();setTimeout(()=>URL.revokeObjectURL(href),500)}
if(CHANNEL==='coolmath'){$('exportButton').style.display='none';$('soundButton').parentNode.style.justifyContent='flex-end';}
$('phaseButton').onclick=toggle;$('undoButton').onclick=undo;$('resetButton').onclick=reset;$('hintButton').onclick=hint;$('prevButton').onclick=()=>select(current-1);$('nextButton').onclick=()=>select(current+1);$('levelMenuButton').onclick=openLevels;$('helpButton').onclick=help;$('exportButton').onclick=downloadTelemetry;$('soundButton').onclick=()=>{sound=!sound;$('soundButton').textContent=sound?'音效：开':'音效：关';beep(650,.08)};
 $('overlay').addEventListener('click',e=>{if(e.target===$('overlay')&&!completionScheduled)closeDialog()});document.addEventListener('keydown',e=>{
  if(!$('overlay').classList.contains('hidden')){
   if(e.key==='Escape'&&!completionScheduled)closeDialog();
   if(e.key==='Tab'){
    const focusables=[...$('modal').querySelectorAll('button:not([disabled]),a[href],input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])')];
    if(focusables.length){const first=focusables[0],last=focusables[focusables.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}
   }
   return;
  }
  if(e.isComposing||e.target.matches('input,textarea,select')||e.target.closest('button,a,[role="button"]'))return;
  if(e.code==='Space'){e.preventDefault();toggle()}else if(e.key.toLowerCase()==='z')undo();else if(e.key.toLowerCase()==='r')reset();
 });
const qp=new URLSearchParams(location.search),requested=Math.max(1,Math.min(levels.length,Number(qp.get('level'))||1));
if(CHANNEL==='demo')window.VectorShiftDebug={getLevel:()=>level(),getState:()=>JSON.parse(JSON.stringify(state)),getProgress:()=>({...progress}),getTelemetry:()=>[...telemetry],getSolution:()=>core.solve(level(),state),setLevel:(n)=>select(n-1),solveAndPlay:()=>{const s=core.solve(level(),state);if(s.actions)for(let a of s.actions)a.type==='toggle'?toggle():remove(a.id)}};
log('session_start',{qa});select((qa||requested<=progress.unlocked)?requested-1:progress.unlocked-1);
})();
