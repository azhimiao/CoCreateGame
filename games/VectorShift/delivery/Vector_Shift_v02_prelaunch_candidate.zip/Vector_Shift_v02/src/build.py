#!/usr/bin/env python3
from pathlib import Path
import json
r=Path(__file__).resolve().parents[1]
template=(r/'src/index.template.html').read_text()
levels=json.dumps(json.loads((r/'data/levels.json').read_text()),ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
for channel in ('demo','coolmath','crazygames-basic'):
    html=template
    pieces={
        '/*INJECT_STYLES*/':(r/'src/styles.css').read_text(),
        '/*INJECT_CHANNEL*/':f'window.VS_CHANNEL={json.dumps(channel)};',
        '/*INJECT_CORE*/':(r/'src/game-core.js').read_text(),
        '/*INJECT_LEVELS*/':levels,
        '/*INJECT_APP*/':(r/'src/app.js').read_text()
    }
    for k,v in pieces.items():
        assert k in html,k
        html=html.replace(k,v)
    if channel=='coolmath':
        html=html.replace('试玩事件只保留在当前浏览器中，可手动导出。','本平台候选版不进行试玩事件记录。')
    if channel!='demo':
        html=html.replace("qa=new URLSearchParams(location.search).has('qa')","qa=false")
    out=r/'dist'/channel/'index.html';out.parent.mkdir(parents=True,exist_ok=True);out.write_text(html,encoding='utf8')
    if channel=='demo':(r/'index.html').write_text(html,encoding='utf8')
    print(channel,len(html.encode()),'bytes')
